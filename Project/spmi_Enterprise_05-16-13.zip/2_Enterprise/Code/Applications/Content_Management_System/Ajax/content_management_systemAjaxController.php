<?php
require_once 'Project/Code/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
	 	
class content_management_systemAjaxController extends applicationsSuperController
{
}