<?php
require_once 'Project/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
require_once 'articleView.php';

require_once FILE_ACCESS_CORE_CODE.'/Modules/Database/starfishDatabase.php';
require_once 'Project/Model/Articles/article.php';
require_once 'Project/Model/Articles/articles.php';
require_once 'Project/Model/Articles/article_image.php';
require_once 'Project/Model/Articles/article_images.php';
require_once 'Project/Model/Articles/article_tags.php';
require_once 'Project/Model/Articles/article_tag.php';
require_once 'Project/Model/Routes/route.php';

require_once 'Project/Model/Articles/article_element.php';

class articleModel
{
	
}


