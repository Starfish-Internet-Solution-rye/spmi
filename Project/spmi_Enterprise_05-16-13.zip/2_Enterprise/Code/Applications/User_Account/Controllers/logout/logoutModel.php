<?php
class accountLogoutModel  
{	
	
}