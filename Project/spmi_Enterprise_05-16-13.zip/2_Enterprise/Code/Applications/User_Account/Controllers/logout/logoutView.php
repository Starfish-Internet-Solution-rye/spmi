<?php
require_once 'Project/ApplicationsFramework/MVC_superClasses/applicationsSuperView.php';

class logoutView extends applicationsSuperView
{
	
	
}