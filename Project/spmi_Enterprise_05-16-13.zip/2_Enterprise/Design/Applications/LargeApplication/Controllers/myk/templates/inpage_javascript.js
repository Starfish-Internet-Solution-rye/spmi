$(document).ready(function(){
	alert('hoy');
});