$(document).ready(function(){	$('input[name="login"]').removeAttr('disabled');
	$('input[name="login"]').attr('title','Get Started!');
	$('#enable_javascript').addClass('hide')
});
