$(document).ready(function(){
	Cufon.replace('header p', { fontFamily: 'Franklin Gothic Book' });
//	Cufon.replace('p', { fontFamily: 'Myriad Pro' });
	Cufon.replace('#primary_nav a,#secondary_nav a', { fontFamily: 'Helvetica Neue LT Std' });
	Cufon.replace('#blueWrap h1', { fontFamily: 'HelveticaNeueLT Com 45 Lt' });
});

