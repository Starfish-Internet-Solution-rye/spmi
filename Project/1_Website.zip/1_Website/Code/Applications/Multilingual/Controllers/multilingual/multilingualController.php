<?php
require_once 'Project/ApplicationsFramework/MVC_superClasses/applicationsSuperController.php';
require_once "Project/1_Website/Code/Applications/Multilingual/Controllers/modules/userSession.php";

class multilingualController extends applicationsSuperController
{
	public function changeLanguageAction()
	{
		$language = $this->getValueOfURLParameterPair('language');
		$location = $_GET['location'];
		
		userSession::saveUserSession($language);
		header("Location: $location");
	}
	
}